# ARC Trainer Project

Welcome to the ARC Trainer Project! This document provides an overview of the folder structure, setup instructions, and how to run the application in a Docker environment.

---

## Folder Structure

```
ARC_Trainer/
├── app.py                  # Main Flask application
├── config.json             # Configuration file for the project
├── docker-compose.yml      # Docker Compose setup
├── Dockerfile              # Dockerfile for the application
├── prolog_rules/           # Folder containing Prolog rule files
│   ├── geometry_rules.pl   # Prolog rules for geometry tasks
│   └── arithmetic_rules.pl # Prolog rules for arithmetic tasks
├── models/                 # Folder for fine-tuned models and logs
│   ├── fine_tuned/         # Saved fine-tuned models
│   └── logs/               # Training logs
├── datasets/               # Folder for storing dataset files
├── src/                    # Source code folder
│   ├── graph_rag.py        # Graph-based Reasoning and Knowledge
│   ├── user_feedback.py    # User feedback management
│   ├── control_agent.py    # Task control and Prolog integration
│   ├── learning_agent.py   # Machine learning integration
│   ├── llm_client.py       # Language model client
│   ├── task_manager.py     # Task management and queueing
│   ├── language_game_trainer.py # Training language games
│   ├── llm_fine_tuner.py   # Fine-tuning LLMs
│   ├── counterexample_finder.py # Counterexample identification
│   └── kg_visualizer.py    # Knowledge graph visualization
└── requirements.txt        # Python dependencies
```

---

## Setup Instructions

### Prerequisites

Make sure you have the following software installed:

- **Docker**: [Download Docker](https://www.docker.com/products/docker-desktop)
- **Docker Compose**: Installed as part of Docker Desktop.

---

### Environment Setup

1. **Clone the Repository**:
    ```bash
    git clone https://github.com/your-repo/ARC_Trainer.git
    cd ARC_Trainer
    ```

2. **Configure Environment**:
    - Modify the `config.json` file with your Neo4j credentials, API keys, and Prolog rule paths.

3. **Build Docker Image**:
    ```bash
    docker-compose build
    ```

4. **Run the Application**:
    ```bash
    docker-compose up
    ```

    This command will start the Flask server, Neo4j, and any other services defined in `docker-compose.yml`.

---

## Docker Setup

### Dockerfile

```Dockerfile
# Base image
FROM python:3.9-slim

# Set working directory
WORKDIR /app

# Install dependencies
COPY requirements.txt ./
RUN pip install --no-cache-dir -r requirements.txt

# Copy project files
COPY . .

# Expose the application port
EXPOSE 5000

# Start the application
CMD ["python", "app.py"]
```

### docker-compose.yml

```yaml
version: '3.8'

services:
  app:
    build: .
    ports:
      - "5000:5000"
    volumes:
      - .:/app
    environment:
      - CONFIG_FILE=config.json

  neo4j:
    image: neo4j:latest
    ports:
      - "7474:7474"
      - "7687:7687"
    environment:
      - NEO4J_AUTH=neo4j/password
    volumes:
      - neo4j_data:/data

volumes:
  neo4j_data:
```

---

## Usage

1. **Submit a Task**:
   - Use the `/tasks` endpoint to submit a task.

2. **Check Task Status**:
   - Use the `/tasks/<task_id>` endpoint to check task progress.

3. **Submit Feedback**:
   - Use the `/feedback` endpoint to submit user feedback.

4. **Visualize Knowledge Graph**:
   - Access the `kg_visualizer.py` to generate graph visualizations.

---

## Additional Notes

- Default Neo4j credentials are set as `neo4j/password`. Update these in `docker-compose.yml` and `config.json` for production use.
- Ensure that Prolog rule files are correctly placed in the `prolog_rules/` directory.
- Use the `requirements.txt` file to manage Python dependencies if running outside Docker.

---

Happy training!
